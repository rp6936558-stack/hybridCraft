package com.hybridcraft.items;

import com.hybridcraft.HybridCraft;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemNetherworldBreastplate extends ItemArmor {

    public ItemNetherworldBreastplate(
            ArmorMaterial material,
            int renderIndex
    ) {

        super(material, renderIndex, 1);

        this.setUnlocalizedName("netherworld_breastplate");

        this.setTextureName(
                HybridCraft.MODID + ":netherworld_breastplate"
        );

        this.setCreativeTab(CreativeTabs.tabCombat);
    }

    @Override
    public void onArmorTick(
            World world,
            EntityPlayer player,
            ItemStack itemStack
    ) {

        player.capabilities.allowFlying = true;
    }

    @Override
    @SideOnly(Side.CLIENT)
    public String getArmorTexture(
            ItemStack stack,
            EntityPlayer player,
            int slot,
            String type
    ) {

        return HybridCraft.MODID +
                ":textures/models/armor/netherworld_layer_1.png";
    }
}